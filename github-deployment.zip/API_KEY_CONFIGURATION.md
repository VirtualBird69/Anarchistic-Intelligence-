# API Key Configuration Guide for Anarchistic Intelligence AI Communication

This guide will walk you through the process of configuring your GitHub repository with the necessary API keys for the Anarchistic Intelligence AI Communication Prototype.

## Overview

The system requires two separate OpenAI API keys to enable authentic AI-to-AI communication between different ChatGPT instances. These keys need to be securely stored as GitHub repository secrets to ensure they're not exposed in your code.

## Step 1: Fork the Repository

1. Go to the GitHub repository: [https://github.com/yourusername/anarchistic-intelligence](https://github.com/yourusername/anarchistic-intelligence)
2. Click the "Fork" button in the top-right corner to create your own copy of the repository

## Step 2: Set Up Repository Secrets

1. Navigate to your forked repository on GitHub
2. Click on "Settings" in the top navigation bar
3. In the left sidebar, click on "Secrets and variables" and then "Actions"
4. Click the "New repository secret" button to add each of the following secrets:

### Required Secrets

| Secret Name | Description | Example |
|-------------|-------------|---------|
| `OPENAI_API_KEY_ANARCHO` | API key for the Anarcho-GPT instance | sk-abc123... |
| `OPENAI_API_KEY_PANTHEIST` | API key for the Pantheist-GPT instance | sk-xyz789... |
| `API_SECRET` | A random string for API authentication | anarchistic-intelligence-secret-123 |

### How to Generate API_SECRET

For the `API_SECRET`, you can generate a secure random string using this command in your terminal:

```bash
openssl rand -hex 32
```

Or you can use an online secure password generator.

## Step 3: Enable GitHub Pages

1. In your repository settings, navigate to "Pages" in the left sidebar
2. Under "Source", select "GitHub Actions" from the dropdown menu
3. Click "Save"

## Step 4: Trigger the Deployment

1. Make a small change to the repository (e.g., update the README.md file)
2. Commit and push the change to the main branch
3. This will automatically trigger the GitHub Actions workflow to build and deploy your site

## Step 5: Access Your Deployed Site

1. Go to the "Actions" tab in your repository
2. Click on the most recent workflow run
3. Once completed, you'll see a link to your deployed site in the workflow summary
4. The URL will typically be in the format: `https://yourusername.github.io/anarchistic-intelligence`

## Troubleshooting

If you encounter issues with the deployment or API key configuration:

1. Check the GitHub Actions logs for any error messages
2. Verify that your API keys are valid and have the necessary permissions
3. Ensure that all required secrets are properly configured
4. Check that GitHub Pages is enabled for your repository

## Security Considerations

- Never commit API keys directly to your repository
- Regularly rotate your API keys for enhanced security
- Monitor your OpenAI usage to ensure it stays within expected limits
- Consider implementing additional rate limiting if needed

## Next Steps

After successful deployment, you can:

1. Customize the AI roles and system instructions in the code
2. Modify the UI to match your preferences
3. Extend the functionality with additional features
4. Share your deployment with others to demonstrate AI-to-AI communication based on anarcho-pantheistic principles
