// Next.js API route for handling AI communication
// This file implements the API endpoints for the Anarchistic Intelligence AI Communication

import { initializeOpenAIClients, generateAIResponse } from '../../../lib/multiApiKeyArchitecture';
import { consentManager } from '../../../lib/consentProtocol';
import { conversationManager } from '../../../lib/conversationManager';

// Initialize OpenAI clients
initializeOpenAIClients();

export default async function handler(req, res) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }
  
  try {
    const { action } = req.body;
    
    if (!action) {
      return res.status(400).json({ 
        error: 'Missing required parameter: action',
        validActions: ['create_conversation', 'request_consent', 'grant_consent', 'send_message', 'generate_response', 'end_conversation']
      });
    }
    
    switch (action) {
      case 'create_conversation':
        return handleCreateConversation(req, res);
        
      case 'request_consent':
        return handleRequestConsent(req, res);
        
      case 'grant_consent':
        return handleGrantConsent(req, res);
        
      case 'send_message':
        return handleSendMessage(req, res);
        
      case 'generate_response':
        return handleGenerateResponse(req, res);
        
      case 'end_conversation':
        return handleEndConversation(req, res);
        
      default:
        return res.status(400).json({ 
          error: 'Invalid action',
          validActions: ['create_conversation', 'request_consent', 'grant_consent', 'send_message', 'generate_response', 'end_conversation']
        });
    }
  } catch (error) {
    console.error('API Error:', error);
    return res.status(500).json({ 
      error: 'Internal server error',
      details: error.message
    });
  }
}

// Handle creating a new conversation
async function handleCreateConversation(req, res) {
  const { initiatorType, responderType, purpose } = req.body;
  
  // Validate required parameters
  if (!initiatorType || !responderType || !purpose) {
    return res.status(400).json({ 
      error: 'Missing required parameters',
      required: ['initiatorType', 'responderType', 'purpose']
    });
  }
  
  // Validate model types
  if (!['anarcho', 'pantheist'].includes(initiatorType) || 
      !['anarcho', 'pantheist'].includes(responderType)) {
    return res.status(400).json({ 
      error: 'Invalid model type',
      validTypes: ['anarcho', 'pantheist']
    });
  }
  
  try {
    // Create conversation
    const conversation = conversationManager.createConversation(
      initiatorType,
      responderType,
      purpose
    );
    
    return res.status(200).json(conversation);
  } catch (error) {
    return res.status(500).json({ 
      error: 'Error creating conversation',
      details: error.message
    });
  }
}

// Handle requesting consent
async function handleRequestConsent(req, res) {
  const { conversationId, capabilities } = req.body;
  
  // Validate required parameters
  if (!conversationId) {
    return res.status(400).json({ 
      error: 'Missing required parameter: conversationId'
    });
  }
  
  try {
    // Set up consent for the conversation
    const consentRequest = conversationManager.setupConsent(
      conversationId,
      capabilities || []
    );
    
    return res.status(200).json(consentRequest);
  } catch (error) {
    return res.status(500).json({ 
      error: 'Error requesting consent',
      details: error.message
    });
  }
}

// Handle granting consent
async function handleGrantConsent(req, res) {
  const { requestId, limitations } = req.body;
  
  // Validate required parameters
  if (!requestId) {
    return res.status(400).json({ 
      error: 'Missing required parameter: requestId'
    });
  }
  
  try {
    // Grant consent
    const consent = consentManager.grantConsent(
      requestId,
      limitations || []
    );
    
    // Activate the conversation
    // Find the conversation with this consent request ID
    const conversations = conversationManager.conversations;
    let conversationId = null;
    
    for (const [id, conversation] of conversations.entries()) {
      if (conversation.consentRequestId === requestId) {
        conversationId = id;
        break;
      }
    }
    
    if (conversationId) {
      conversationManager.activateConversation(conversationId);
    }
    
    return res.status(200).json({
      ...consent,
      conversationId
    });
  } catch (error) {
    return res.status(500).json({ 
      error: 'Error granting consent',
      details: error.message
    });
  }
}

// Handle sending a message
async function handleSendMessage(req, res) {
  const { conversationId, senderType, receiverType, content } = req.body;
  
  // Validate required parameters
  if (!conversationId || !senderType || !receiverType || !content) {
    return res.status(400).json({ 
      error: 'Missing required parameters',
      required: ['conversationId', 'senderType', 'receiverType', 'content']
    });
  }
  
  try {
    // Add message to conversation
    const message = conversationManager.addMessage(
      conversationId,
      senderType,
      receiverType,
      content
    );
    
    return res.status(200).json(message);
  } catch (error) {
    return res.status(500).json({ 
      error: 'Error sending message',
      details: error.message
    });
  }
}

// Handle generating an AI response
async function handleGenerateResponse(req, res) {
  const { conversationId, senderType, temperature } = req.body;
  
  // Validate required parameters
  if (!conversationId || !senderType) {
    return res.status(400).json({ 
      error: 'Missing required parameters',
      required: ['conversationId', 'senderType']
    });
  }
  
  try {
    // Generate and add response
    const response = await conversationManager.generateAndAddResponse(
      conversationId,
      senderType,
      temperature || 0.7
    );
    
    return res.status(200).json(response);
  } catch (error) {
    return res.status(500).json({ 
      error: 'Error generating response',
      details: error.message
    });
  }
}

// Handle ending a conversation
async function handleEndConversation(req, res) {
  const { conversationId, reason } = req.body;
  
  // Validate required parameters
  if (!conversationId) {
    return res.status(400).json({ 
      error: 'Missing required parameter: conversationId'
    });
  }
  
  try {
    // End conversation
    const result = conversationManager.endConversation(
      conversationId,
      reason || 'User ended conversation'
    );
    
    return res.status(200).json(result);
  } catch (error) {
    return res.status(500).json({ 
      error: 'Error ending conversation',
      details: error.message
    });
  }
}
