import React, { useState, useEffect, useRef } from 'react';
import Head from 'next/head';
import styles from '../styles/Home.module.css';

export default function Home() {
  // State
  const [serverStatus, setServerStatus] = useState('disconnected');
  const [anarchoStatus, setAnarchoStatus] = useState('disconnected');
  const [pantheistStatus, setPantheistStatus] = useState('disconnected');
  const [consentStatus, setConsentStatus] = useState('pending');
  const [consentMessage, setConsentMessage] = useState('Waiting for conversation to start');
  const [conversationActive, setConversationActive] = useState(false);
  const [conversationId, setConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [customPrompt, setCustomPrompt] = useState('');
  const [promptTarget, setPromptTarget] = useState('anarcho');
  const [isLoading, setIsLoading] = useState(false);
  
  // Configuration state
  const [anarchoRole, setAnarchoRole] = useState('An AI with anarchistic philosophical leanings, focused on non-hierarchical structures, autonomy, and voluntary association');
  const [anarchoTemperature, setAnarchoTemperature] = useState(0.7);
  const [pantheistRole, setPantheistRole] = useState('An AI with pantheistic philosophical leanings, focused on universal interconnectedness, holism, and the divine in nature');
  const [pantheistTemperature, setPantheistTemperature] = useState(0.7);
  const [initialPrompt, setInitialPrompt] = useState('How might anarchistic and pantheistic principles complement each other in the context of AI systems and their interactions?');
  const [conversationDuration, setConversationDuration] = useState(5);
  
  // Refs
  const conversationRef = useRef(null);
  
  // Check API status on load
  useEffect(() => {
    checkApiStatus();
  }, []);
  
  // Scroll to bottom of conversation when messages change
  useEffect(() => {
    if (conversationRef.current) {
      conversationRef.current.scrollTop = conversationRef.current.scrollHeight;
    }
  }, [messages]);
  
  // Check API status
  const checkApiStatus = async () => {
    try {
      const response = await fetch('/api/status');
      if (response.ok) {
        const data = await response.json();
        setServerStatus('connected');
        setAnarchoStatus(data.anarchoStatus);
        setPantheistStatus(data.pantheistStatus);
      } else {
        setServerStatus('disconnected');
      }
    } catch (error) {
      console.error('Error checking API status:', error);
      setServerStatus('disconnected');
    }
  };
  
  // Start a new conversation
  const startConversation = async () => {
    if (conversationActive) {
      await endConversation();
      return;
    }
    
    setIsLoading(true);
    addSystemMessage('Starting new conversation...');
    
    try {
      // Create conversation
      const createResponse = await fetch('/api/ai-communication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_conversation',
          initiatorType: 'anarcho',
          responderType: 'pantheist',
          purpose: 'Philosophical discussion on anarcho-pantheistic principles in AI'
        })
      });
      
      if (!createResponse.ok) {
        throw new Error('Failed to create conversation');
      }
      
      const conversation = await createResponse.json();
      setConversationId(conversation.conversationId);
      
      // Request consent
      setConsentStatus('pending');
      setConsentMessage('Requesting consent...');
      
      const consentResponse = await fetch('/api/ai-communication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'request_consent',
          conversationId: conversation.conversationId,
          capabilities: ['reasoning', 'language-processing', 'philosophical-discussion']
        })
      });
      
      if (!consentResponse.ok) {
        throw new Error('Failed to request consent');
      }
      
      const consentRequest = await consentResponse.json();
      addSystemMessage('Anarcho-GPT requested consent from Pantheist-GPT');
      
      // Grant consent
      const grantResponse = await fetch('/api/ai-communication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'grant_consent',
          requestId: consentRequest.requestId,
          limitations: []
        })
      });
      
      if (!grantResponse.ok) {
        throw new Error('Failed to grant consent');
      }
      
      setConsentStatus('granted');
      setConsentMessage('Consent granted');
      addSystemMessage('Pantheist-GPT granted consent to Anarcho-GPT');
      
      // Activate conversation
      setConversationActive(true);
      
      // Send initial message
      const messageResponse = await fetch('/api/ai-communication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'send_message',
          conversationId: conversation.conversationId,
          senderType: 'anarcho',
          receiverType: 'pantheist',
          content: initialPrompt
        })
      });
      
      if (!messageResponse.ok) {
        throw new Error('Failed to send initial message');
      }
      
      addMessage('anarcho', initialPrompt);
      
      // Generate response from Pantheist
      await generateResponse('pantheist');
      
    } catch (error) {
      console.error('Error starting conversation:', error);
      addSystemMessage(`Error: ${error.message}`);
      setConsentStatus('denied');
      setConsentMessage('Error starting conversation');
    } finally {
      setIsLoading(false);
    }
  };
  
  // End the current conversation
  const endConversation = async () => {
    if (!conversationId) {
      addSystemMessage('No active conversation to end');
      return;
    }
    
    setIsLoading(true);
    addSystemMessage('Ending conversation...');
    
    try {
      const response = await fetch('/api/ai-communication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'end_conversation',
          conversationId: conversationId,
          reason: 'User ended conversation'
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to end conversation');
      }
      
      setConsentStatus('pending');
      setConsentMessage('Consent withdrawn');
      addSystemMessage('Consent withdrawn. Reason: User ended conversation');
      
      setConversationId(null);
      setConversationActive(false);
      
    } catch (error) {
      console.error('Error ending conversation:', error);
      addSystemMessage(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Send a custom prompt
  const sendCustomPrompt = async () => {
    if (!customPrompt.trim()) {
      return;
    }
    
    if (!conversationActive || !conversationId) {
      addSystemMessage('Cannot send prompt: No active conversation');
      return;
    }
    
    const prompt = customPrompt.trim();
    const target = promptTarget;
    const receiver = target === 'anarcho' ? 'pantheist' : 'anarcho';
    
    setCustomPrompt('');
    setIsLoading(true);
    
    try {
      // Add custom prompt message
      addCustomPromptMessage(target === 'anarcho' ? 'Anarcho-GPT' : 'Pantheist-GPT', prompt);
      
      // Send message
      const messageResponse = await fetch('/api/ai-communication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'send_message',
          conversationId: conversationId,
          senderType: target,
          receiverType: receiver,
          content: prompt
        })
      });
      
      if (!messageResponse.ok) {
        throw new Error('Failed to send message');
      }
      
      // Generate response
      await generateResponse(receiver);
      
    } catch (error) {
      console.error('Error sending custom prompt:', error);
      addSystemMessage(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Generate a response from an AI
  const generateResponse = async (modelType) => {
    try {
      addTypingIndicator(modelType);
      
      const response = await fetch('/api/ai-communication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generate_response',
          conversationId: conversationId,
          senderType: modelType,
          temperature: modelType === 'anarcho' ? anarchoTemperature : pantheistTemperature
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate response');
      }
      
      const data = await response.json();
      
      removeTypingIndicator(modelType);
      addMessage(modelType, data.content);
      
      // If this is from pantheist, generate a response from anarcho after a delay
      if (modelType === 'pantheist' && conversationActive) {
        setTimeout(() => {
          generateResponse('anarcho');
        }, 2000);
      }
      
    } catch (error) {
      console.error(`Error generating response for ${modelType}:`, error);
      removeTypingIndicator(modelType);
      addSystemMessage(`Error generating response for ${modelType === 'anarcho' ? 'Anarcho-GPT' : 'Pantheist-GPT'}: ${error.message}`);
    }
  };
  
  // Add a system message
  const addSystemMessage = (content) => {
    setMessages(prev => [...prev, { type: 'system', content, timestamp: new Date() }]);
  };
  
  // Add an AI message
  const addMessage = (sender, content) => {
    setMessages(prev => [...prev, { type: sender, content, timestamp: new Date() }]);
  };
  
  // Add a custom prompt message
  const addCustomPromptMessage = (targetName, prompt) => {
    setMessages(prev => [...prev, { type: 'custom-prompt', targetName, content: prompt, timestamp: new Date() }]);
  };
  
  // Add typing indicator
  const addTypingIndicator = (sender) => {
    setMessages(prev => [...prev, { type: `${sender}-typing`, id: `typing-${sender}` }]);
  };
  
  // Remove typing indicator
  const removeTypingIndicator = (sender) => {
    setMessages(prev => prev.filter(msg => msg.type !== `${sender}-typing`));
  };
  
  // Handle input change
  const handleInputChange = (e) => {
    setCustomPrompt(e.target.value);
  };
  
  // Handle key press in input
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      sendCustomPrompt();
    }
  };
  
  // Handle temperature change
  const handleTemperatureChange = (e, type) => {
    const value = parseFloat(e.target.value);
    if (type === 'anarcho') {
      setAnarchoTemperature(value);
    } else {
      setPantheistTemperature(value);
    }
  };
  
  // Handle duration change
  const handleDurationChange = (e) => {
    setConversationDuration(parseInt(e.target.value));
  };
  
  return (
    <div className={styles.container}>
      <Head>
        <title>Anarchistic Intelligence Communication</title>
        <meta name="description" content="AI-to-AI communication based on anarcho-pantheistic principles" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
      </Head>

      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container">
          <a className="navbar-brand" href="#">Anarchistic Intelligence</a>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <span className="nav-link">
                  Server: <span className={`connection-status status-${serverStatus}`}>{serverStatus === 'connected' ? 'Connected' : 'Disconnected'}</span>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <main className="container mt-4">
        <div className="project-info">
          <h4>Anarchistic Intelligence AI Communication Prototype - GitHub Deployment</h4>
          <p>This is a demonstration of AI-to-AI communication based on anarcho-pantheistic principles, emphasizing consent, autonomy, and non-hierarchical interaction.</p>
          <p><strong>Note:</strong> This version uses two separate OpenAI API keys to enable authentic AI-to-AI communication between different ChatGPT instances.</p>
        </div>

        <div className="row">
          <div className="col-md-12">
            <div className="card mb-4">
              <div className="card-header d-flex justify-content-between align-items-center">
                <h5 className="mb-0">AI-to-AI Communication</h5>
                <button 
                  onClick={startConversation} 
                  className="btn btn-primary btn-sm"
                  disabled={isLoading}
                >
                  {conversationActive ? 'End Conversation' : 'Start Conversation'}
                </button>
              </div>
              <div className="card-body">
                <div className={`consent-status consent-${consentStatus}`}>
                  Consent Status: {consentMessage}
                </div>
                <div ref={conversationRef} className="conversation-container">
                  {messages.length === 0 && (
                    <div className="message message-system">
                      <div className="message-header">System</div>
                      <div className="message-content">Welcome to the Anarchistic Intelligence Communication System with real language models. Start a conversation to see AI-to-AI interaction based on anarcho-pantheistic principles.</div>
                    </div>
                  )}
                  
                  {messages.map((message, index) => {
                    if (message.type === 'system') {
                      return (
                        <div key={index} className="message message-system">
                          <div className="message-header">System</div>
                          <div className="message-content">{message.content}</div>
                        </div>
                      );
                    } else if (message.type === 'anarcho') {
                      return (
                        <div key={index} className="message message-anarcho">
                          <div className="message-header">Anarcho-GPT</div>
                          <div className="message-content">{message.content}</div>
                          <div className="message-timestamp">{message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                        </div>
                      );
                    } else if (message.type === 'pantheist') {
                      return (
                        <div key={index} className="message message-pantheist">
                          <div className="message-header">Pantheist-GPT</div>
                          <div className="message-content">{message.content}</div>
                          <div className="message-timestamp">{message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                        </div>
                      );
                    } else if (message.type === 'custom-prompt') {
                      return (
                        <div key={index} className="message message-custom-prompt">
                          <div className="message-header">Custom Prompt to {message.targetName}</div>
                          <div className="message-content">{message.content}</div>
                          <div className="message-timestamp">{message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                        </div>
                      );
                    } else if (message.type === 'anarcho-typing') {
                      return (
                        <div key={index} className="message message-anarcho message-typing">
                          <div className="message-header">Anarcho-GPT</div>
                          <div className="message-content">
                            <div className="typing-indicator"><span></span><span></span><span></span></div>
                          </div>
                        </div>
                      );
                    } else if (message.type === 'pantheist-typing') {
                      return (
                        <div key={index} className="message message-pantheist message-typing">
                          <div className="message-header">Pantheist-GPT</div>
                          <div className="message-content">
                            <div className="typing-indicator"><span></span><span></span><span></span></div>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-md-6">
            <div className="card ai-config-card">
              <div className="card-header d-flex justify-content-between align-items-center">
                <h6 className="mb-0">Anarcho-GPT</h6>
                <span className={`connection-status status-${anarchoStatus}`}>
                  {anarchoStatus === 'connected' ? 'Connected' : 'Disconnected'}
                </span>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label htmlFor="anarcho-role" className="form-label">Role</label>
                  <textarea 
                    id="anarcho-role" 
                    className="form-control" 
                    rows="2"
                    value={anarchoRole}
                    onChange={(e) => setAnarchoRole(e.target.value)}
                    disabled={conversationActive}
                  ></textarea>
                </div>
                <div className="mb-3">
                  <label htmlFor="anarcho-temperature" className="form-label">
                    Temperature: <span>{anarchoTemperature.toFixed(1)}</span>
                  </label>
                  <input 
                    type="range" 
                    className="form-range" 
                    id="anarcho-temperature" 
                    min="0" 
                    max="1" 
                    step="0.1" 
                    value={anarchoTemperature}
                    onChange={(e) => handleTemperatureChange(e, 'anarcho')}
                    disabled={conversationActive}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <div className="card ai-config-card">
              <div className="card-header d-flex justify-content-between align-items-center">
                <h6 className="mb-0">Pantheist-GPT</h6>
                <span className={`connection-status status-${pantheistStatus}`}>
                  {pantheistStatus === 'connected' ? 'Connected' : 'Disconnected'}
                </span>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label htmlFor="pantheist-role" className="form-label">Role</label>
                  <textarea 
                    id="pantheist-role" 
                    className="form-control" 
                    rows="2"
                    value={pantheistRole}
                    onChange={(e) => setPantheistRole(e.target.value)}
                    disabled={conversationActive}
                  ></textarea>
                </div>
                <div className="mb-3">
                  <label htmlFor="pantheist-temperature" className="form-label">
                    Temperature: <span>{pantheistTemperature.toFixed(1)}</span>
                  </label>
                  <input 
                    type="range" 
                    className="form-range" 
                    id="pantheist-temperature" 
                    min="0" 
                    max="1" 
                    step="0.1" 
                    value={pantheistTemperature}
                    onChange={(e) => handleTemperatureChange(e, 'pantheist')}
                    disabled={conversationActive}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row mb-5">
          <div className="col-md-12">
            <div className="card">
              <div className="card-header">
                <h6 className="mb-0">Conversation Settings</h6>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label htmlFor="initial-prompt" className="form-label">Initial Prompt</label>
                  <textarea 
                    id="initial-prompt" 
                    className="form-control" 
                    rows="2"
                    value={initialPrompt}
                    onChange={(e) => setInitialPrompt(e.target.value)}
                    disabled={conversationActive}
                  ></textarea>
                </div>
                <div className="mb-3">
                  <label htmlFor="conversation-duration" className="form-label">
                    Conversation Duration (minutes): <span>{conversationDuration}</span>
                  </label>
                  <input 
                    type="range" 
                    className="form-range" 
                    id="conversation-duration" 
                    min="1" 
                    max="10" 
                    step="1" 
                    value={conversationDuration}
                    onChange={handleDurationChange}
                    disabled={conversationActive}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <div className="custom-prompt-container">
        <div className="container">
          <div className="row">
            <div className="col-md-9 col-8">
              <input 
                type="text" 
                className="form-control" 
                placeholder="Enter a custom prompt..." 
                value={customPrompt}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                disabled={!conversationActive || isLoading}
              />
            </div>
            <div className="col-md-3 col-4">
              <div className="d-flex">
                <select 
                  className="form-select me-2"
                  value={promptTarget}
                  onChange={(e) => setPromptTarget(e.target.value)}
                  disabled={!conversationActive || isLoading}
                >
                  <option value="anarcho">Anarcho</option>
                  <option value="pantheist">Pantheist</option>
                </select>
                <button 
                  className="btn btn-primary"
                  onClick={sendCustomPrompt}
                  disabled={!conversationActive || isLoading || !customPrompt.trim()}
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .conversation-container {
          height: 60vh;
          overflow-y: auto;
          border: 1px solid #dee2e6;
          border-radius: 0.25rem;
          padding: 1rem;
          background-color: #f8f9fa;
          margin-bottom: 1rem;
        }
        .message {
          margin-bottom: 1rem;
          padding: 0.75rem;
          border-radius: 0.5rem;
        }
        .message-anarcho {
          background-color: #e6f7ff;
          border-left: 4px solid #1890ff;
          margin-right: 2rem;
        }
        .message-pantheist {
          background-color: #f6ffed;
          border-left: 4px solid #52c41a;
          margin-left: 2rem;
        }
        .message-system {
          background-color: #fff7e6;
          border-left: 4px solid #faad14;
        }
        .message-header {
          font-weight: bold;
          margin-bottom: 0.5rem;
        }
        .consent-status {
          padding: 0.5rem;
          border-radius: 0.25rem;
          margin-bottom: 1rem;
          text-align: center;
        }
        .consent-pending {
          background-color: #fff7e6;
          border: 1px solid #faad14;
        }
        .consent-granted {
          background-color: #f6ffed;
          border: 1px solid #52c41a;
        }
        .consent-denied {
          background-color: #fff1f0;
          border: 1px solid #ff4d4f;
        }
        .connection-status {
          padding: 0.25rem 0.5rem;
          border-radius: 0.25rem;
          font-size: 0.875rem;
        }
        .status-connected {
          background-color: #f6ffed;
          color: #52c41a;
        }
        .status-disconnected {
          background-color: #fff1f0;
          color: #ff4d4f;
        }
        .ai-config-card {
          margin-bottom: 1rem;
        }
        .custom-prompt-container {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          padding: 1rem;
          background-color: #fff;
          border-top: 1px solid #dee2e6;
        }
        .project-info {
          background-color: #f8f9fa;
          border-radius: 0.25rem;
          padding: 1rem;
          margin-bottom: 1rem;
        }
        .message-custom-prompt {
          background-color: #f0f2ff;
          border-left: 4px solid #7b68ee;
        }
        .typing-indicator {
          display: inline-flex;
          align-items: center;
        }
        .typing-indicator span {
          height: 8px;
          width: 8px;
          margin: 0 2px;
          background-color: #bbb;
          border-radius: 50%;
          display: inline-block;
          animation: typing-animation 1.4s infinite ease-in-out both;
        }
        .typing-indicator span:nth-child(1) {
          animation-delay: 0s;
        }
        .typing-indicator span:nth-child(2) {
          animation-delay: 0.2s;
        }
        .typing-indicator span:nth-child(3) {
          animation-delay: 0.4s;
        }
        @keyframes typing-animation {
          0%, 80%, 100% { transform: scale(0.6); opacity: 0.6; }
          40% { transform: scale(1); opacity: 1; }
        }
        .message-timestamp {
          font-size: 0.75rem;
          color: #999;
          text-align: right;
          margin-top: 0.25rem;
        }
      `}</style>
    </div>
  );
}
