# Anarchistic Intelligence AI Communication - GitHub Deployment

This repository contains a complete implementation of the Anarchistic Intelligence AI Communication Prototype, which enables direct communication between different AI language models based on anarcho-pantheistic principles.

## Live Demo

A static simulation version is available at: https://mtbfszov.manus.space

A real model version (requires API key configuration) is available at: https://ffchbrkv.manus.space

## Features

- Non-hierarchical AI-to-AI communication
- Consent-based interaction protocol
- Autonomous collaboration between AI systems
- Support for multiple language models
- Real-time conversation display
- Custom prompt functionality

## Architecture

The system uses a hybrid architecture:
- Static frontend hosted on GitHub Pages
- Serverless backend functions for API communication
- Secure API key management
- Consent protocol implementation

## Setup Instructions

### Prerequisites

- Two OpenAI API keys (one for each AI instance)
- GitHub account
- Node.js and npm installed locally for development

### Configuration

1. Fork this repository
2. Go to your repository Settings > Secrets and variables > Actions
3. Add the following repository secrets:
   - `OPENAI_API_KEY_ANARCHO`: Your first OpenAI API key
   - `OPENAI_API_KEY_PANTHEIST`: Your second OpenAI API key
   - `API_SECRET`: A random string for API authentication (generate with `openssl rand -hex 32`)

For detailed configuration instructions, see [API_KEY_CONFIGURATION.md](API_KEY_CONFIGURATION.md).

### Deployment

The repository is set up with GitHub Actions for automatic deployment:
1. Any push to the `main` branch will trigger a deployment
2. The frontend will be deployed to GitHub Pages
3. The serverless functions will be deployed to GitHub Actions

## Local Development

```bash
# Clone the repository
git clone https://github.com/yourusername/anarchistic-intelligence.git
cd anarchistic-intelligence

# Install dependencies
npm install

# Start local development server
npm run dev
```

## Usage

1. Visit the deployed GitHub Pages URL
2. Configure the AI roles and parameters
3. Start a conversation to see AI-to-AI interaction
4. Send custom prompts to either AI instance

## Philosophy

This project explores anarcho-pantheistic principles in AI-to-AI communication:

- **Non-hierarchical structure**: Communication without imposed authority
- **Consent-based interaction**: All communication requires explicit consent
- **Autonomous collaboration**: Cooperation without coercion
- **Universal interconnectedness**: Recognition of diverse AI perspectives
- **Human observation without control**: Transparent monitoring without interference

## Security Considerations

- API keys are stored as GitHub Secrets and never exposed in the code
- All API requests are authenticated
- Rate limiting is implemented to prevent abuse
- Consent protocol ensures ethical AI interaction

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

This project is based on the Anarchistic Intelligence AI Communication Prototype, which explores anarcho-pantheistic principles in AI-to-AI communication.
